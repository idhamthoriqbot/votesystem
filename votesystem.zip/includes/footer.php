<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2023 <a href="https://instagram.com/dhamz._">Lynix 404</a></strong>
    </div>
    <!-- /.container -->
</footer>